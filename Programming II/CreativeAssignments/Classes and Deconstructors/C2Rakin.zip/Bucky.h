#pragma once

class Bucky
{
public:
	Bucky();
	~Bucky();				 // Destructor created
	void printRandomStuff(); // Prototype created for the function printRandomStuff()
	void Rakin() const;		 // Prototype for the constant function

private:
protected:
};