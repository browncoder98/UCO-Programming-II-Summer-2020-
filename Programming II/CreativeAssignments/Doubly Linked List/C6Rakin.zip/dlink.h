#pragma once

struct Node
{
	int data;
	Node *next;
	Node *prev;
};

class DoublyList
{
public:
	Node *head; //head for the list

	DoublyList();
	Node *create(int);
	void InsertBegin(int);
	void Display();
	Node *Merge(Node **, Node **);
	void MergeSort(Node **);
	void Split(Node **, Node **, Node *);
};