extern void f1();
extern void f2();
extern void f3();
extern void f4();
extern void f5();
int main()
{
    f1();
    f2();
    f3();
    f4();
    f5();
}